﻿[app]

title = Cute Online AI
package.name = cuteai
package.domain = org.cuteai

source.dir = .
source.include_exts = py,ttf,png,jpg

version = 1.0

requirements = python3,kivy,arabic-reshaper,python-bidi

orientation = portrait

fullscreen = 0


[buildozer]

log_level = 2
warn_on_root = 1