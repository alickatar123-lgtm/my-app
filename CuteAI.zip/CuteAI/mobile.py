﻿```python
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.core.text import LabelBase
from kivy.clock import Clock

import arabic_reshaper
from bidi.algorithm import get_display

import json
import threading
import urllib.request
import urllib.error


# -----------------------------
# Persian text
# -----------------------------

LabelBase.register(name="Tahoma", fn_regular="tahoma.ttf")


def fa(text):
    return get_display(arabic_reshaper.reshape(text))


# -----------------------------
# OpenAI request
# -----------------------------

def ask_openai(api_key, message, callback):

    def worker():

        try:
            url = "https://api.openai.com/v1/responses"

            data = {
                "model": "gpt-5",
                "input": message
            }

            body = json.dumps(data).encode("utf-8")

            request = urllib.request.Request(
                url,
                data=body,
                method="POST"
            )

            request.add_header(
                "Authorization",
                "Bearer " + api_key
            )

            request.add_header(
                "Content-Type",
                "application/json"
            )

            response = urllib.request.urlopen(
                request,
                timeout=60
            )

            result = json.loads(
                response.read().decode("utf-8")
            )

            answer = result.get("output_text", "")

            if not answer:
                answer = "پاسخی دریافت نشد."

            Clock.schedule_once(
                lambda dt: callback(answer)
            )

        except urllib.error.HTTPError as e:

            try:
                error_text = e.read().decode("utf-8")
            except:
                error_text = str(e)

            Clock.schedule_once(
                lambda dt: callback(
                    "خطای OpenAI:\n" + error_text
                )
            )

        except Exception as e:

            Clock.schedule_once(
                lambda dt: callback(
                    "خطا در اتصال:\n" + str(e)
                )
            )

    threading.Thread(
        target=worker,
        daemon=True
    ).start()


# -----------------------------
# Cute AI
# -----------------------------

class CuteAI(App):

    def build(self):

        layout = BoxLayout(
            orientation="vertical",
            padding=10,
            spacing=10
        )

        self.api_key = TextInput(
            hint_text=fa("کلید OpenAI را وارد کنید"),
            password=True,
            font_name="Tahoma",
            font_size=18,
            multiline=False,
            size_hint_y=None,
            height=55
        )

        self.chat = Label(
            text=fa(
                "Cute Online AI\n\n"
                "سلام! من آماده‌ام 😊\n\n"
                "اول کلید OpenAI را وارد کنید."
            ),
            font_name="Tahoma",
            font_size=20,
            halign="right",
            valign="top"
        )

        self.chat.bind(
            size=self.chat.setter("text_size")
        )

        self.entry = TextInput(
            hint_text=fa("پیامت را بنویس..."),
            font_name="Tahoma",
            font_size=20,
            multiline=False,
            size_hint_y=None,
            height=60
        )

        self.button = Button(
            text=fa("ارسال"),
            font_name="Tahoma",
            font_size=22,
            size_hint_y=None,
            height=60
        )

        self.button.bind(
            on_press=self.send_message
        )

        layout.add_widget(self.api_key)
        layout.add_widget(self.chat)
        layout.add_widget(self.entry)
        layout.add_widget(self.button)

        return layout


    def send_message(self, instance):

        api_key = self.api_key.text.strip()
        text = self.entry.text.strip()

        if not api_key:

            self.chat.text = fa(
                "لطفاً اول کلید OpenAI را وارد کنید."
            )

            return

        if not text:
            return

        self.button.disabled = True

        self.chat.text += "\n\n" + fa(
            "شما: " + text
        )

        self.chat.text += "\n" + fa(
            "AI: در حال فکر کردن..."
        )

        self.entry.text = ""

        ask_openai(
            api_key,
            text,
            self.show_answer
        )


    def show_answer(self, answer):

        self.chat.text += "\n" + fa(
            "AI: " + answer
        )

        self.button.disabled = False


CuteAI().run()
```

